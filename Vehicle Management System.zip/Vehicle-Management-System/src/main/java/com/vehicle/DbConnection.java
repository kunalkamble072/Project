package com.vehicle;
import java.sql.*;

public class DbConnection {
	
	public Connection makeConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url= "jdbc:mysql://localhost:3306/Vehicle_management";
		String username="root";
		String password="2003";
		
		Connection con = DriverManager.getConnection(url,username,password);
		
        return con;
	}
}
